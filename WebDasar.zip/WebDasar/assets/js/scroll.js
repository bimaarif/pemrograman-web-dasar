
var i = 0;
var image = [];
var time = 4000;

//image list

image[0] = 'assets/img/1.png';
image[1] = 'assets/img/2.png';
image[2] = 'assets/img/3.png';
image[3] = 'assets/img/4.png';
image[4] = 'assets/img/5.png';
image[5] = 'assets/img/6.png';

function changeImage(){
	document.slideShow.src = image[i];

	if (i < image.length - 1) {
		i++;
	}else{
		i=0;
	}
	setTimeout("changeImage()", time);
}

window.onload = changeImage;